/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sw;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.Cliente;
import modelo.DetalleFactura;
import modelo.Factura;
import modelo.Producto;

/**
 *
 * @author mauri
 */
@WebService(serviceName = "ConversionSW")
public class ConversionSW {

    ArrayList<Cliente> listaClientes = new ArrayList<>();
    ArrayList<Factura> listaFacturas = new ArrayList<>();
    ArrayList<DetalleFactura> listaDetalleFacturas = new ArrayList<>();
    ArrayList<Producto> listaProductos = new ArrayList<>();

    public void CargarDatos() {
        // Crear clientes
        Cliente cliente1 = new Cliente(1, "Juan Pérez");
        Cliente cliente2 = new Cliente(2, "María López");
        Cliente cliente3 = new Cliente(3, "Carlos García");
        Cliente cliente4 = new Cliente(4, "Ana Fernández");

// Agregar clientes a la lista
        listaClientes.add(cliente1);
        listaClientes.add(cliente2);
        listaClientes.add(cliente3);
        listaClientes.add(cliente4);

// Crear productos
        Producto producto1 = new Producto(1, "Laptop", 750.50, 10);
        Producto producto2 = new Producto(2, "Mouse", 20.99, 50);
        Producto producto3 = new Producto(3, "Teclado", 45.89, 30);
        Producto producto4 = new Producto(4, "Monitor", 200.00, 15);
        Producto producto5 = new Producto(5, "Impresora", 120.75, 25);
        Producto producto6 = new Producto(6, "Auriculares", 35.99, 40);

// Agregar productos a la lista
        listaProductos.add(producto1);
        listaProductos.add(producto2);
        listaProductos.add(producto3);
        listaProductos.add(producto4);
        listaProductos.add(producto5);
        listaProductos.add(producto6);

// Crear facturas
        List<DetalleFactura> detallesFactura1 = new ArrayList<>();
        List<DetalleFactura> detallesFactura2 = new ArrayList<>();
        List<DetalleFactura> detallesFactura3 = new ArrayList<>();
        List<DetalleFactura> detallesFactura4 = new ArrayList<>();

        Factura factura1 = new Factura(1001, new Date(), cliente1, detallesFactura1);
        Factura factura2 = new Factura(1002, new Date(), cliente2, detallesFactura2);
        Factura factura3 = new Factura(1003, new Date(), cliente3, detallesFactura3);
        Factura factura4 = new Factura(1004, new Date(), cliente3, detallesFactura4);

// Agregar facturas a la lista
        listaFacturas.add(factura1);
        listaFacturas.add(factura2);
        listaFacturas.add(factura3);
        listaFacturas.add(factura4);

// Crear detalles de factura
        DetalleFactura detalle1 = new DetalleFactura(1, factura1, producto1, 1); // 1 Laptop
        DetalleFactura detalle2 = new DetalleFactura(2, factura1, producto2, 2); // 2 Mouse
        DetalleFactura detalle3 = new DetalleFactura(3, factura2, producto3, 1); // 1 Teclado
        DetalleFactura detalle4 = new DetalleFactura(4, factura2, producto4, 1); // 1 Monitor
        DetalleFactura detalle5 = new DetalleFactura(5, factura3, producto5, 3); // 3 Impresoras
        DetalleFactura detalle6 = new DetalleFactura(6, factura3, producto6, 2); // 2 Auriculares
        DetalleFactura detalle7 = new DetalleFactura(7, factura4, producto2, 5); // 5 Mouse
        DetalleFactura detalle8 = new DetalleFactura(8, factura4, producto4, 2); // 2 Monitores

// Agregar detalles a las facturas
        detallesFactura1.add(detalle1);
        detallesFactura1.add(detalle2);

        detallesFactura2.add(detalle3);
        detallesFactura2.add(detalle4);

        detallesFactura3.add(detalle5);
        detallesFactura3.add(detalle6);

        detallesFactura4.add(detalle7);
        detallesFactura4.add(detalle8);

// Agregar detalles a la lista global de detalles de factura
        listaDetalleFacturas.add(detalle1);
        listaDetalleFacturas.add(detalle2);
        listaDetalleFacturas.add(detalle3);
        listaDetalleFacturas.add(detalle4);
        listaDetalleFacturas.add(detalle5);
        listaDetalleFacturas.add(detalle6);
        listaDetalleFacturas.add(detalle7);
        listaDetalleFacturas.add(detalle8);

    }

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello => " + txt + ", Este metodo esta funcionando bien!";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "listaClientes")
    public List<Cliente> listaClientes() {
        //TODO write your implementation code here:
        if (listaClientes.isEmpty()) {
            CargarDatos();
        }
        return listaClientes;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "listaFacturaId")
    public List<Factura> listaFacturaId(@WebParam(name = "id") int id) {
        //TODO write your implementation code here:
        if (listaFacturas.isEmpty()) {
            CargarDatos();
        }
        List<Factura> facturas = new ArrayList<>();
        try {
            // Buscar facturas del cliente por su id
            for (Factura factura : listaFacturas) {
                if (factura.getCliente().getCedula() == id) {
                    facturas.add(factura);
                }
            }
        } catch (Exception e) {
            System.out.println("Error al obtener las facturas: " + e.getMessage());
            e.printStackTrace();
        }
        return facturas;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "listarProductos")
    public List<Producto> listarProductos() {
        //TODO write your implementation code here:
        if (listaProductos.isEmpty()) {
            CargarDatos();
        }

        // Devolver la lista de productos directamente
        return listaProductos;
    }

}
