/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mauri
 */
@XmlRootElement
public class DetalleFactura {
    
    private int numDetalle;
    private Producto producto;
    private int cantidad;
    
    @XmlTransient
    private Factura factura;

    public DetalleFactura() {
    }

    public DetalleFactura(int numDetalle, Factura factura, Producto producto, int cantidad) {
        this.numDetalle = numDetalle;
        this.factura = factura;
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public int getNumDetalle() {
        return numDetalle;
    }

    public void setNumDetalle(int numDetalle) {
        this.numDetalle = numDetalle;
    }

//    public Factura getFactura() {
//        return factura;
//    }
//
//    public void setFactura(Factura factura) {
//        this.factura = factura;
//    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
}
