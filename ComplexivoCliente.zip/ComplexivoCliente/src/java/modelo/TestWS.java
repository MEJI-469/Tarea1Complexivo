/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.List;
import sw.Cliente;
import sw.ConversionSW;
import sw.ConversionSW_Service;
import sw.DetalleFactura;
import sw.Factura;
import sw.Producto;

/**
 *
 * @author mauri
 */
public class TestWS {

    public static void main(String[] args) {
        ConversionSW_Service service = new ConversionSW_Service();
        ConversionSW port = service.getConversionSWPort();

        // Llamar al servicio para obtener la lista de clientes
        List<Cliente> clientes = port.listaClientes();
        System.out.println("Lista de Clientes:");
        for (Cliente cliente : clientes) {
            System.out.println("ID: " + cliente.getCedula() + ", Nombre: " + cliente.getNombre());
        }

        // Llamar al servicio para obtener la lista de productos
        List<Producto> productos = port.listarProductos();
        System.out.println("\nLista de Productos:");
        for (Producto producto : productos) {
            System.out.println("ID: " + producto.getId() + ", Nombre: " + producto.getNombre()
                    + ", Precio: " + producto.getPrecio() + ", Stock: " + producto.getStock());
        }

        // Llamar al servicio para obtener las facturas de un cliente por cédula (asumimos que la cédula es un ID)
        int clienteId = 3; // Cambia esto por el ID del cliente que quieras consultar
        List<Factura> facturas = port.listaFacturaId(clienteId);
        System.out.println("\nFacturas del Cliente ID " + clienteId + ":");
        for (Factura factura : facturas) {
            System.out.println("Factura ID: " + factura.getNumero() + ", Fecha: " + factura.getFecha()
                    + ", Cliente: " + factura.getCliente().getNombre());
            List<DetalleFactura> detalle = factura.getDetalles();
            for (DetalleFactura detfac : detalle) {
                System.out.println("    Producto: " + detfac.getProducto().getNombre() + " Cantidad: " + detfac.getCantidad());
            }
        }

    }

}
